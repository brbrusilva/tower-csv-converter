# Conversor de Planilhas para o Tower

Este app converte arquivos CSV para os formatos aceitos pela ferramenta Tower: Tabela de Abrangência ou Tabela Frete/Peso.

✔️ Detecta automaticamente o tipo de tabela  
✔️ Padroniza as colunas no formato correto  
✔️ Permite baixar o CSV convertido

Feito com 💛 por Bruna
